"""
TabunganKita - Realtime Tabungan Bersama
Deploy ke Railway: https://railway.app
"""

from flask import Flask, request, jsonify, Response, render_template_string
import json, os, time, threading, queue

app = Flask(__name__)

# ── In-memory data (Railway tidak punya persistent disk di free tier) ─────────
_data = {"target": 0, "name1": "Orang Pertama", "name2": "Orang Kedua", "entries": []}
_data_lock = threading.Lock()

# Coba load dari file kalau ada (untuk local dev)
DATA_FILE = "tabungan_data.json"
if os.path.exists(DATA_FILE):
    try:
        with open(DATA_FILE, encoding="utf-8") as f:
            _data = json.load(f)
    except Exception:
        pass

def get_data():
    with _data_lock:
        return dict(_data)

def set_data(d):
    global _data
    with _data_lock:
        _data = d
    # Simpan ke file kalau bisa (local dev)
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

# ── SSE broadcast ─────────────────────────────────────────────────────────────
_clients = []
_clients_lock = threading.Lock()

def broadcast(event, data):
    payload = f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
    with _clients_lock:
        dead = []
        for q in _clients:
            try:
                q.put_nowait(payload)
            except queue.Full:
                dead.append(q)
        for q in dead:
            _clients.remove(q)

# ── HTML ──────────────────────────────────────────────────────────────────────
HTML = r"""<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TabunganKita 💰</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root{--bg:#0f0e17;--card:#1a1825;--card2:#211e30;--accent:#f9c74f;--accent2:#f3722c;--green:#43aa8b;--text:#fffffe;--muted:#a7a9be;--border:rgba(249,199,79,0.15)}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;overflow-x:hidden}
body::before{content:'';position:fixed;top:-200px;right:-200px;width:600px;height:600px;background:radial-gradient(circle,rgba(249,199,79,.08) 0%,transparent 70%);pointer-events:none}
body::after{content:'';position:fixed;bottom:-200px;left:-200px;width:500px;height:500px;background:radial-gradient(circle,rgba(243,114,44,.06) 0%,transparent 70%);pointer-events:none}
header{text-align:center;padding:48px 24px 24px}
header h1{font-family:'Playfair Display',serif;font-size:clamp(2.2rem,6vw,3.5rem);font-weight:900;background:linear-gradient(135deg,var(--accent),var(--accent2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;letter-spacing:-1px}
header p{color:var(--muted);font-size:.95rem;margin-top:6px;font-weight:300}
.status-bar{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:12px;flex-wrap:wrap}
.badge{display:inline-flex;align-items:center;gap:6px;background:rgba(249,199,79,.1);border:1px solid var(--border);border-radius:100px;padding:4px 14px;font-size:.75rem;color:var(--accent)}
.live-badge{display:inline-flex;align-items:center;gap:6px;border-radius:100px;padding:4px 14px;font-size:.75rem;font-weight:600;transition:all .3s}
.live-badge.connected{background:rgba(67,170,139,.15);border:1px solid rgba(67,170,139,.4);color:var(--green)}
.live-badge.disconnected{background:rgba(255,107,107,.1);border:1px solid rgba(255,107,107,.3);color:#ff6b6b}
.live-dot{width:7px;height:7px;border-radius:50%;background:currentColor}
.live-badge.connected .live-dot{animation:pulse 1.5s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
.viewers-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:100px;padding:4px 14px;font-size:.75rem;color:var(--muted)}
.container{max-width:900px;margin:0 auto;padding:0 20px 80px}

/* TARGET */
.target-card{background:linear-gradient(135deg,#1a1825,#211e30);border:1px solid var(--border);border-radius:20px;padding:28px;margin-bottom:24px;position:relative;overflow:hidden}
.target-card::before{content:'🎯';position:absolute;right:20px;top:20px;font-size:2rem;opacity:.3}
.target-card h2{font-size:.8rem;color:var(--accent);margin-bottom:16px;font-weight:700;letter-spacing:1px;text-transform:uppercase}
.target-amount{font-family:'Playfair Display',serif;font-size:clamp(2rem,5vw,3rem);font-weight:900}
.target-amount.unset{color:var(--muted);font-size:1.4rem}
.progress-bar{margin-top:20px;background:rgba(255,255,255,.06);border-radius:100px;height:14px;overflow:hidden}
.progress-fill{height:100%;background:linear-gradient(90deg,var(--green),var(--accent));border-radius:100px;transition:width .8s cubic-bezier(.34,1.56,.64,1);position:relative}
.progress-fill::after{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.3),transparent);animation:shimmer 2s infinite}
@keyframes shimmer{0%{transform:translateX(-100%)}100%{transform:translateX(100%)}}
.progress-info{display:flex;justify-content:space-between;margin-top:10px;font-size:.85rem;color:var(--muted)}
.progress-info strong{color:var(--green);font-size:1rem}
.edit-target-btn{background:none;border:1px solid var(--border);color:var(--accent);font-family:'DM Sans',sans-serif;font-size:.8rem;padding:6px 14px;border-radius:100px;cursor:pointer;margin-top:16px;transition:all .2s}
.edit-target-btn:hover{background:var(--border)}

/* USERS */
.users-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px}
@media(max-width:500px){.users-grid{grid-template-columns:1fr}}
.user-card{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:24px;transition:transform .2s,border-color .2s;position:relative;overflow:hidden}
.user-card:hover{transform:translateY(-3px);border-color:rgba(249,199,79,.3)}
.user-card.user1::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--accent),var(--accent2))}
.user-card.user2::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--green),#4cc9f0)}
.user-avatar{width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin-bottom:12px}
.user1 .user-avatar{background:rgba(249,199,79,.15)}
.user2 .user-avatar{background:rgba(67,170,139,.15)}
.user-name-input{background:none;border:none;border-bottom:1px dashed var(--border);color:var(--text);font-family:'Playfair Display',serif;font-size:1.1rem;font-weight:700;width:100%;outline:none;padding:2px 0}
.user-name-input:focus{border-bottom-color:var(--accent)}
.user-total{font-size:1.6rem;font-family:'Playfair Display',serif;font-weight:900;margin:10px 0 4px}
.user1 .user-total{color:var(--accent)}
.user2 .user-total{color:var(--green)}
.user-count{font-size:.8rem;color:var(--muted)}

/* INPUT */
.input-section{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:28px;margin-bottom:24px}
.input-section h3{font-family:'Playfair Display',serif;font-size:1.3rem;font-weight:700;margin-bottom:20px;color:var(--accent)}
.form-row{display:grid;grid-template-columns:1fr 1fr 1.5fr auto;gap:12px;align-items:end}
@media(max-width:640px){.form-row{grid-template-columns:1fr 1fr}.btn-add{grid-column:span 2}}
label{display:block;font-size:.75rem;color:var(--muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:1px}
select,input[type=number],input[type=text],input[type=month]{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:10px;color:var(--text);font-family:'DM Sans',sans-serif;font-size:.95rem;padding:10px 14px;width:100%;outline:none;transition:border-color .2s;-webkit-appearance:none;appearance:none}
select:focus,input:focus{border-color:var(--accent)}
select option{background:#1a1825}
.btn-add{background:linear-gradient(135deg,var(--accent),var(--accent2));border:none;border-radius:10px;color:#0f0e17;font-family:'DM Sans',sans-serif;font-size:.95rem;font-weight:700;padding:11px 20px;cursor:pointer;transition:opacity .2s,transform .1s;white-space:nowrap}
.btn-add:hover{opacity:.9;transform:translateY(-1px)}
.btn-add:active{transform:scale(.98)}
.btn-add:disabled{opacity:.5;cursor:not-allowed;transform:none}

/* SUMMARY */
.summary-section{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:28px;margin-bottom:24px}
.summary-section h3{font-family:'Playfair Display',serif;font-size:1.3rem;font-weight:700;margin-bottom:16px;color:var(--accent)}
.summary-table{width:100%;border-collapse:collapse}
.summary-table th{text-align:left;font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;padding:8px 12px;border-bottom:1px solid var(--border)}
.summary-table td{padding:10px 12px;font-size:.9rem;border-bottom:1px solid rgba(255,255,255,.04)}
.summary-table tr:last-child td{border-bottom:none}
.month-label{color:var(--muted);font-size:.85rem}
.amt1{color:var(--accent);font-weight:600;font-family:'Playfair Display',serif}
.amt2{color:var(--green);font-weight:600;font-family:'Playfair Display',serif}
.total-row td{font-weight:700;border-top:1px solid var(--border) !important;padding-top:14px !important}

/* HISTORY */
.history-section{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:28px}
.history-section h3{font-family:'Playfair Display',serif;font-size:1.3rem;font-weight:700;margin-bottom:6px;color:var(--accent)}
.history-controls{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:20px;margin-top:12px}
.history-filter{display:flex;gap:8px;flex-wrap:wrap}
.filter-btn{background:rgba(255,255,255,.05);border:1px solid var(--border);border-radius:100px;color:var(--muted);font-family:'DM Sans',sans-serif;font-size:.8rem;padding:5px 14px;cursor:pointer;transition:all .2s}
.filter-btn.active{background:var(--accent);color:#0f0e17;border-color:var(--accent);font-weight:600}
.history-actions{display:flex;gap:8px}
.export-btn{background:none;border:1px solid var(--border);color:var(--muted);font-family:'DM Sans',sans-serif;font-size:.78rem;padding:5px 12px;border-radius:100px;cursor:pointer;transition:all .2s}
.export-btn:hover{color:var(--text);border-color:var(--muted)}
.reset-btn{background:none;border:1px solid rgba(255,107,107,.25);color:#ff6b6b;font-family:'DM Sans',sans-serif;font-size:.78rem;padding:5px 12px;border-radius:100px;cursor:pointer;transition:all .2s}
.reset-btn:hover{background:rgba(255,107,107,.1)}
.history-list{display:flex;flex-direction:column;gap:8px}
.history-item{display:flex;align-items:center;gap:14px;background:rgba(255,255,255,.03);border-radius:12px;padding:14px 16px;animation:fadeIn .35s ease;transition:background .2s}
.history-item:hover{background:rgba(255,255,255,.06)}
.history-item.new-entry{animation:highlight .8s ease forwards}
@keyframes highlight{0%{background:rgba(249,199,79,.2)}100%{background:rgba(255,255,255,.03)}}
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
.item-icon{width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0}
.icon-user1{background:rgba(249,199,79,.15)}
.icon-user2{background:rgba(67,170,139,.15)}
.item-info{flex:1;min-width:0}
.item-who{font-weight:600;font-size:.9rem}
.item-note{font-size:.78rem;color:var(--muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.item-right{text-align:right;flex-shrink:0}
.item-amount{font-family:'Playfair Display',serif;font-weight:700;font-size:1.05rem}
.user1-amount{color:var(--accent)}
.user2-amount{color:var(--green)}
.item-month{font-size:.75rem;color:var(--muted);margin-top:2px}
.item-delete{background:none;border:none;color:rgba(255,255,255,.2);cursor:pointer;font-size:1rem;padding:4px;border-radius:6px;transition:all .2s;flex-shrink:0}
.item-delete:hover{color:#ff6b6b;background:rgba(255,107,107,.1)}
.empty-state{text-align:center;padding:40px;color:var(--muted)}
.empty-state .emoji{font-size:3rem;margin-bottom:12px}

/* MODAL */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:100;align-items:center;justify-content:center}
.modal-overlay.show{display:flex}
.modal{background:var(--card2);border:1px solid var(--border);border-radius:20px;padding:32px;width:90%;max-width:400px;animation:popIn .3s cubic-bezier(.34,1.56,.64,1)}
@keyframes popIn{from{opacity:0;transform:scale(.85)}to{opacity:1;transform:scale(1)}}
.modal h3{font-family:'Playfair Display',serif;font-size:1.3rem;margin-bottom:20px}
.modal p{color:var(--muted);font-size:.9rem;line-height:1.6}
.modal-actions{display:flex;gap:10px;margin-top:20px}
.btn-cancel{flex:1;background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:10px;color:var(--text);font-family:'DM Sans',sans-serif;padding:10px;cursor:pointer}
.btn-save{flex:1;background:linear-gradient(135deg,var(--accent),var(--accent2));border:none;border-radius:10px;color:#0f0e17;font-family:'DM Sans',sans-serif;font-weight:700;padding:10px;cursor:pointer}
.btn-danger{flex:1;background:rgba(255,107,107,.15);border:1px solid rgba(255,107,107,.3);border-radius:10px;color:#ff6b6b;font-family:'DM Sans',sans-serif;font-weight:700;padding:10px;cursor:pointer}
.toast{position:fixed;bottom:30px;left:50%;transform:translateX(-50%) translateY(100px);background:var(--green);color:#fff;font-family:'DM Sans',sans-serif;font-weight:600;padding:12px 24px;border-radius:100px;z-index:200;transition:transform .4s cubic-bezier(.34,1.56,.64,1);white-space:nowrap}
.toast.show{transform:translateX(-50%) translateY(0)}
</style>
</head>
<body>
<header>
  <h1>TabunganKita 💰</h1>
  <p>Tabungan bersama &bull; realtime dari mana saja</p>
  <div class="status-bar">
    <div class="badge">☁️ Online &bull; Bisa diakses siapapun</div>
    <div class="live-badge disconnected" id="liveBadge">
      <span class="live-dot"></span>
      <span id="liveText">Menghubungkan...</span>
    </div>
    <div class="viewers-badge">👁 <span id="viewerCount">1</span> sedang melihat</div>
  </div>
</header>

<div class="container">
  <!-- TARGET -->
  <div class="target-card">
    <h2>🎯 Target Tabungan</h2>
    <div class="target-amount unset" id="displayTarget">Belum diatur</div>
    <div class="progress-bar"><div class="progress-fill" id="progressFill" style="width:0%"></div></div>
    <div class="progress-info">
      <span>Terkumpul: <strong id="totalCollected">Rp 0</strong></span>
      <span id="progressPercent">0%</span>
    </div>
    <button class="edit-target-btn" onclick="openTargetModal()">✏️ Ubah Target</button>
  </div>

  <!-- USERS -->
  <div class="users-grid">
    <div class="user-card user1">
      <div class="user-avatar">👤</div>
      <input class="user-name-input" id="name1" value="Orang Pertama" onblur="updateNames()">
      <div class="user-total" id="total1">Rp 0</div>
      <div class="user-count" id="count1">0 setoran</div>
    </div>
    <div class="user-card user2">
      <div class="user-avatar">👥</div>
      <input class="user-name-input" id="name2" value="Orang Kedua" onblur="updateNames()">
      <div class="user-total" id="total2">Rp 0</div>
      <div class="user-count" id="count2">0 setoran</div>
    </div>
  </div>

  <!-- INPUT -->
  <div class="input-section">
    <h3>+ Catat Setoran</h3>
    <div class="form-row">
      <div>
        <label>Siapa</label>
        <select id="selectUser">
          <option value="1">Orang Pertama</option>
          <option value="2">Orang Kedua</option>
        </select>
      </div>
      <div>
        <label>Bulan</label>
        <input type="month" id="inputMonth">
      </div>
      <div>
        <label>Jumlah (Rp)</label>
        <input type="number" id="inputAmount" placeholder="500000" min="0">
      </div>
      <button class="btn-add" id="btnAdd" onclick="addEntry()">Tambah</button>
    </div>
    <div style="margin-top:12px">
      <label>Catatan (opsional)</label>
      <input type="text" id="inputNote" placeholder="Misal: Nabung gajian bulan ini...">
    </div>
  </div>

  <!-- SUMMARY -->
  <div class="summary-section">
    <h3>📊 Rekap Per Bulan</h3>
    <div style="overflow-x:auto">
      <table class="summary-table">
        <thead>
          <tr>
            <th>Bulan</th><th id="th1">Orang Pertama</th><th id="th2">Orang Kedua</th><th>Total</th>
          </tr>
        </thead>
        <tbody id="summaryBody">
          <tr><td colspan="4" style="text-align:center;color:var(--muted);padding:20px">Belum ada data</td></tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- HISTORY -->
  <div class="history-section">
    <h3>Riwayat Setoran</h3>
    <div class="history-controls">
      <div class="history-filter">
        <button class="filter-btn active" onclick="setFilter('all',this)">Semua</button>
        <button class="filter-btn" onclick="setFilter('1',this)" id="filter1">Orang Pertama</button>
        <button class="filter-btn" onclick="setFilter('2',this)" id="filter2">Orang Kedua</button>
      </div>
      <div class="history-actions">
        <button class="export-btn" onclick="exportCSV()">⬇ Export CSV</button>
        <button class="reset-btn" onclick="openResetModal()">🗑 Reset</button>
      </div>
    </div>
    <div class="history-list" id="historyList">
      <div class="empty-state"><div class="emoji">⏳</div><div>Memuat data...</div></div>
    </div>
  </div>
</div>

<!-- MODAL TARGET -->
<div class="modal-overlay" id="targetModal">
  <div class="modal">
    <h3>🎯 Ubah Target Tabungan</h3>
    <label>Target Jumlah (Rp)</label>
    <input type="number" id="modalTargetInput" placeholder="10000000" style="margin-bottom:0">
    <div class="modal-actions">
      <button class="btn-cancel" onclick="closeModal('targetModal')">Batal</button>
      <button class="btn-save" onclick="saveTarget()">Simpan</button>
    </div>
  </div>
</div>

<!-- MODAL RESET -->
<div class="modal-overlay" id="resetModal">
  <div class="modal">
    <h3>⚠️ Reset Semua Data?</h3>
    <p>Semua setoran akan dihapus permanen. Aksi ini tidak bisa dibatalkan.</p>
    <div class="modal-actions">
      <button class="btn-cancel" onclick="closeModal('resetModal')">Batal</button>
      <button class="btn-danger" onclick="resetAll()">Ya, Hapus Semua</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
let D={target:0,name1:'Orang Pertama',name2:'Orang Kedua',entries:[]};
let filter='all',sse=null;
const now=new Date();
document.getElementById('inputMonth').value=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;

function connectSSE(){
  if(sse)sse.close();
  sse=new EventSource('/stream');
  sse.onopen=()=>{
    const b=document.getElementById('liveBadge');
    b.className='live-badge connected';
    document.getElementById('liveText').textContent='Live';
  };
  sse.addEventListener('update',e=>{
    const fresh=JSON.parse(e.data);
    const isNew=fresh.entries.length>D.entries.length;
    const newId=isNew?fresh.entries[fresh.entries.length-1]?.id:null;
    D=fresh;
    render(newId);
  });
  sse.addEventListener('viewers',e=>{
    document.getElementById('viewerCount').textContent=e.data;
  });
  sse.onerror=()=>{
    const b=document.getElementById('liveBadge');
    b.className='live-badge disconnected';
    document.getElementById('liveText').textContent='Terputus — mencoba ulang...';
    sse.close();
    setTimeout(connectSSE,3000);
  };
}

async function api(method,path,body){
  const opts={method,headers:{'Content-Type':'application/json'}};
  if(body)opts.body=JSON.stringify(body);
  const res=await fetch(path,opts);
  return res.json();
}

async function addEntry(){
  const user=document.getElementById('selectUser').value;
  const month=document.getElementById('inputMonth').value;
  const amount=parseFloat(document.getElementById('inputAmount').value);
  const note=document.getElementById('inputNote').value.trim();
  if(!amount||amount<=0){
    const el=document.getElementById('inputAmount');
    el.style.borderColor='#ff6b6b';el.focus();
    setTimeout(()=>el.style.borderColor='',1000);return;
  }
  const btn=document.getElementById('btnAdd');
  btn.disabled=true;btn.textContent='...';
  await api('POST','/api/entry',{user,month,amount,note});
  btn.disabled=false;btn.textContent='Tambah';
  document.getElementById('inputAmount').value='';
  document.getElementById('inputNote').value='';
  showToast('💰 Setoran berhasil dicatat!');
}

async function deleteEntry(id){await api('DELETE',`/api/entry/${id}`);showToast('🗑 Setoran dihapus');}
async function updateNames(){
  await api('POST','/api/names',{
    name1:document.getElementById('name1').value||'Orang Pertama',
    name2:document.getElementById('name2').value||'Orang Kedua'
  });
}
async function saveTarget(){
  const val=parseFloat(document.getElementById('modalTargetInput').value);
  if(val>0){await api('POST','/api/target',{target:val});showToast('🎯 Target diperbarui!');}
  closeModal('targetModal');
}
async function resetAll(){
  await api('POST','/api/reset');
  closeModal('resetModal');showToast('♻️ Data direset');
}

function rp(n){return 'Rp '+Number(n).toLocaleString('id-ID');}
function fmtMonth(m){
  if(!m)return '';
  const[y,mo]=m.split('-');
  return['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'][+mo-1]+' '+y;
}

function render(newId=null){
  document.getElementById('name1').value=D.name1;
  document.getElementById('name2').value=D.name2;
  document.getElementById('selectUser').options[0].text=D.name1;
  document.getElementById('selectUser').options[1].text=D.name2;
  document.getElementById('filter1').textContent=D.name1;
  document.getElementById('filter2').textContent=D.name2;
  document.getElementById('th1').textContent=D.name1;
  document.getElementById('th2').textContent=D.name2;

  const e1=D.entries.filter(e=>e.user==1);
  const e2=D.entries.filter(e=>e.user==2);
  const s1=e1.reduce((a,b)=>a+b.amount,0);
  const s2=e2.reduce((a,b)=>a+b.amount,0);
  const total=s1+s2;
  document.getElementById('total1').textContent=rp(s1);
  document.getElementById('total2').textContent=rp(s2);
  document.getElementById('count1').textContent=`${e1.length} setoran`;
  document.getElementById('count2').textContent=`${e2.length} setoran`;
  document.getElementById('totalCollected').textContent=rp(total);

  const t=D.target||0;
  const tEl=document.getElementById('displayTarget');
  tEl.textContent=t>0?rp(t):'Belum diatur';
  tEl.className='target-amount'+(t>0?'':' unset');
  const pct=t>0?Math.min(100,Math.round(total/t*100)):0;
  document.getElementById('progressFill').style.width=pct+'%';
  document.getElementById('progressPercent').textContent=pct+'%';

  const months=[...new Set(D.entries.map(e=>e.month))].sort();
  const tbody=document.getElementById('summaryBody');
  if(!months.length){
    tbody.innerHTML=`<tr><td colspan="4" style="text-align:center;color:var(--muted);padding:20px">Belum ada data</td></tr>`;
  }else{
    let g1=0,g2=0;
    tbody.innerHTML=months.map(m=>{
      const m1=D.entries.filter(e=>e.month===m&&e.user==1).reduce((a,b)=>a+b.amount,0);
      const m2=D.entries.filter(e=>e.month===m&&e.user==2).reduce((a,b)=>a+b.amount,0);
      g1+=m1;g2+=m2;
      return`<tr><td class="month-label">${fmtMonth(m)}</td><td class="amt1">${m1>0?rp(m1):'—'}</td><td class="amt2">${m2>0?rp(m2):'—'}</td><td style="font-weight:600">${rp(m1+m2)}</td></tr>`;
    }).join('')+`<tr class="total-row"><td style="color:var(--muted)">Total</td><td class="amt1">${rp(g1)}</td><td class="amt2">${rp(g2)}</td><td style="font-family:'Playfair Display',serif;font-size:1.05rem">${rp(g1+g2)}</td></tr>`;
  }

  const list=document.getElementById('historyList');
  let entries=[...D.entries].reverse();
  if(filter!=='all')entries=entries.filter(e=>e.user==filter);
  if(!entries.length){
    list.innerHTML=`<div class="empty-state"><div class="emoji">🪙</div><div>Belum ada setoran</div></div>`;return;
  }
  list.innerHTML=entries.map(e=>`
    <div class="history-item${e.id===newId?' new-entry':''}" id="item-${e.id}">
      <div class="item-icon icon-user${e.user}">${e.user==1?'👤':'👥'}</div>
      <div class="item-info">
        <div class="item-who">${e.user==1?D.name1:D.name2}</div>
        <div class="item-note">${e.note||'—'}</div>
      </div>
      <div class="item-right">
        <div class="item-amount user${e.user}-amount">${rp(e.amount)}</div>
        <div class="item-month">${fmtMonth(e.month)}</div>
      </div>
      <button class="item-delete" onclick="deleteEntry('${e.id}')">🗑</button>
    </div>`).join('');
}

function setFilter(f,btn){
  filter=f;
  document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');render();
}
function openTargetModal(){
  document.getElementById('modalTargetInput').value=D.target||'';
  document.getElementById('targetModal').classList.add('show');
  setTimeout(()=>document.getElementById('modalTargetInput').focus(),100);
}
function openResetModal(){document.getElementById('resetModal').classList.add('show');}
function closeModal(id){document.getElementById(id).classList.remove('show');}
document.querySelectorAll('.modal-overlay').forEach(m=>{
  m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('show');});
});
function showToast(msg){
  const t=document.getElementById('toast');
  t.textContent=msg;t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),2500);
}
document.getElementById('inputAmount').addEventListener('keydown',e=>{if(e.key==='Enter')addEntry();});
document.getElementById('modalTargetInput').addEventListener('keydown',e=>{if(e.key==='Enter')saveTarget();});
connectSSE();
</script>
</body>
</html>"""

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template_string(HTML)

@app.route("/stream")
def stream():
    q = queue.Queue(maxsize=20)
    with _clients_lock:
        _clients.append(q)
    broadcast("viewers", len(_clients))

    def event_stream():
        data = get_data()
        yield f"event: update\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
        try:
            while True:
                try:
                    msg = q.get(timeout=25)
                    yield msg
                except queue.Empty:
                    yield ": heartbeat\n\n"
        except GeneratorExit:
            pass
        finally:
            with _clients_lock:
                if q in _clients:
                    _clients.remove(q)
            broadcast("viewers", len(_clients))

    return Response(event_stream(),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@app.route("/api/entry", methods=["POST"])
def add_entry():
    data = get_data()
    body = request.json
    entry = {
        "id": str(int(time.time() * 1000)),
        "user": body["user"],
        "month": body.get("month", ""),
        "amount": float(body["amount"]),
        "note": body.get("note", ""),
    }
    data["entries"].append(entry)
    set_data(data)
    broadcast("update", data)
    return jsonify({"ok": True})

@app.route("/api/entry/<eid>", methods=["DELETE"])
def delete_entry(eid):
    data = get_data()
    data["entries"] = [e for e in data["entries"] if e["id"] != eid]
    set_data(data)
    broadcast("update", data)
    return jsonify({"ok": True})

@app.route("/api/names", methods=["POST"])
def update_names():
    data = get_data()
    body = request.json
    data["name1"] = body.get("name1", data["name1"])
    data["name2"] = body.get("name2", data["name2"])
    set_data(data)
    broadcast("update", data)
    return jsonify({"ok": True})

@app.route("/api/target", methods=["POST"])
def update_target():
    data = get_data()
    data["target"] = float(request.json.get("target", 0))
    set_data(data)
    broadcast("update", data)
    return jsonify({"ok": True})

@app.route("/api/reset", methods=["POST"])
def reset():
    data = get_data()
    data["entries"] = []
    data["target"] = 0
    set_data(data)
    broadcast("update", data)
    return jsonify({"ok": True})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
