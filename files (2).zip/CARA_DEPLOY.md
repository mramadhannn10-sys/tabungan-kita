# 💰 TabunganKita — Deploy ke Railway (GRATIS)

Website tabungan realtime yang bisa diakses dari mana saja, WiFi apapun.

---

## 🚀 Cara Deploy ke Railway (5 menit, gratis)

### Langkah 1 — Buat akun GitHub
Kalau belum punya: https://github.com/signup

### Langkah 2 — Upload file ke GitHub
1. Buka https://github.com/new
2. Beri nama repo, misal: `tabungan-kita`
3. Klik **Create repository**
4. Upload 3 file ini: `app.py`, `requirements.txt`, `Procfile`
   - Klik **uploading an existing file**
   - Drag & drop ketiga file → klik **Commit changes**

### Langkah 3 — Deploy ke Railway
1. Buka https://railway.app
2. Klik **Login with GitHub**
3. Klik **New Project** → **Deploy from GitHub repo**
4. Pilih repo `tabungan-kita`
5. Railway otomatis detect Python & deploy! ⚡

### Langkah 4 — Dapat link publik
1. Di Railway, klik project kamu
2. Klik tab **Settings** → **Networking**
3. Klik **Generate Domain**
4. Kamu dapat link seperti: `https://tabungan-kita-xxx.railway.app`

**Bagikan link itu ke siapapun — bisa dibuka dari HP, laptop, WiFi manapun! 🌍**

---

## 📁 File yang dibutuhkan
| File | Fungsi |
|------|--------|
| `app.py` | Server Python Flask utama |
| `requirements.txt` | Daftar library Python |
| `Procfile` | Perintah jalankan server di Railway |

---

## ✅ Fitur
- 🌍 Bisa diakses dari mana saja (beda WiFi)
- ⚡ Realtime — update instan ke semua browser
- 🟢 Indikator Live + jumlah viewer
- 📊 Rekap per bulan
- ⬇ Export CSV
- 💾 Data tersimpan di server

---

## ⚠️ Catatan
Railway free tier: **500 jam/bulan** (cukup untuk pakai terus-menerus ~21 hari).
Untuk pemakaian penuh sebulan, upgrade ke Hobby plan ($5/bulan).

Alternatif gratis lain: **Render.com** (deploy sama caranya, tapi server sleep setelah 15 menit tidak ada request).
